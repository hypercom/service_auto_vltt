<?php

//headers
header('Access-Control-Allow-Origin: *');

//initializing api
include_once('initialize.php');
include 'apihelper.php';

$found=null;
if(isset($_GET['id']) && isset($_GET['pass'])){
    $name = $_GET['id'];
    $pass = $_GET['pass'];

    $data = array("id" => $name, "pass" => $pass);
    $found = callAPI('GET', $url, $data);
    $found = json_decode($found);
}

if(is_null($found)){
    echo 'false| sai tai khoan hoac mat khau';
}else{
    echo 'true|' . $found->code . '|' . $found->numb;
}

