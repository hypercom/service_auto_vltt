<?php

//headers
header('Access-Control-Allow-Origin: *');

//initializing api
defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
defined('SITE_ROOT') ? null : define('SITE_ROOT', DS . 'xampp'.DS.'htdocs');

date_default_timezone_set("Asia/Ho_Chi_Minh");
$date = date('H|i|d|m', time());
echo $date;